package com.hossein7box.chortke;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int BACKUP_CREATE_REQUEST = 1002;
    private static final int BACKUP_OPEN_REQUEST = 1003;
    private String pendingBackupJson;
    private long lastBackPressedAt = 0L;
    private static final long DOUBLE_BACK_WINDOW = 2000L;
    private File backupDir;
    private String pendingAuthCallbackUrl;
    private boolean webViewReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLACK));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        setContentView(webView);

        backupDir = new File(getExternalFilesDir(null), "پشتیبان برنامه");
        if (!backupDir.exists()) backupDir.mkdirs();

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                webViewReady = true;
                dispatchPendingAuthCallback();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });

        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView,
                                              ValueCallback<Uri[]> callback,
                                              FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "انتخاب فایل در دسترس نیست", Toast.LENGTH_SHORT).show();
                    return false;
                }
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "مدیریت فایل پیدا نشد", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        if (getIntent() != null && getIntent().getData() != null) {
            pendingAuthCallbackUrl = getIntent().getData().toString();
        }

        webView.loadUrl("file:///android_asset/index.html");
    }


    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getData() != null) {
            pendingAuthCallbackUrl = intent.getData().toString();
            dispatchPendingAuthCallback();
        }
    }

    private void dispatchPendingAuthCallback() {
        if (pendingAuthCallbackUrl == null || pendingAuthCallbackUrl.isEmpty()) return;
        if (webView == null || !webViewReady) return;

        final String callback = pendingAuthCallbackUrl;
        pendingAuthCallbackUrl = null;
        final String safeUrl = JSONObject.quote(callback);
        webView.post(() -> webView.evaluateJavascript(
                "window.handleChortkeAuthCallback && window.handleChortkeAuthCallback(" + safeUrl + ")",
                null));
    }

    private void handleAuthCallback(String url) {
        if (url == null || url.isEmpty()) return;
        pendingAuthCallbackUrl = url;
        dispatchPendingAuthCallback();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    result = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        result[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        } else if (requestCode == BACKUP_CREATE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                    if (os == null) throw new Exception("open output failed");
                    os.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "نسخه پشتیبان در محل انتخاب‌شده ذخیره شد", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "ذخیره فایل پشتیبان ناموفق بود", Toast.LENGTH_LONG).show();
                }
            }
            pendingBackupJson = null;
        } else if (requestCode == BACKUP_OPEN_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (InputStream is = getContentResolver().openInputStream(data.getData())) {
                    if (is == null) throw new Exception("open input failed");
                    java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = is.read(buffer)) > 0) bos.write(buffer, 0, n);
                    String raw = bos.toString("UTF-8");
                    String quoted = JSONObject.quote(raw);
                    webView.post(() -> webView.evaluateJavascript("window.receiveNativeBackup && window.receiveNativeBackup(" + quoted + ")", null));
                } catch (Exception e) {
                    Toast.makeText(this, "خواندن فایل پشتیبان ناموفق بود", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    private void finishFromBack() {
        long now = System.currentTimeMillis();
        if (now - lastBackPressedAt < DOUBLE_BACK_WINDOW) {
            finish();
            return;
        }
        lastBackPressedAt = now;
        Toast.makeText(this, "برای خروج دوباره دکمه برگشت را بزنید", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        if (webView == null) { finishFromBack(); return; }
        webView.evaluateJavascript("window.handleNativeBack ? window.handleNativeBack() : 'exit'", value -> {
            if ("\"handled\"".equals(value)) {
                lastBackPressedAt = 0L;
            } else {
                finishFromBack();
            }
        });
    }

    private class BackupBridge {
        @JavascriptInterface
        public void exportBackup(String json) {
            runOnUiThread(() -> {
                try {
                    pendingBackupJson = json;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, "CHORTKE-backup-" + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date()) + ".json");
                    startActivityForResult(intent, BACKUP_CREATE_REQUEST);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    Toast.makeText(MainActivity.this, "انتخاب محل ذخیره پشتیبان ممکن نیست", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void chooseBackupFile() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(intent, BACKUP_OPEN_REQUEST);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "انتخاب فایل پشتیبان ممکن نیست", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public String saveBackup(String json) {
            try {
                if (!backupDir.exists() && !backupDir.mkdirs()) return "error";
                String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
                File out = new File(backupDir, "CHORTKE-backup-" + stamp + ".json");
                try (FileOutputStream fos = new FileOutputStream(out)) {
                    fos.write(json.getBytes(StandardCharsets.UTF_8));
                }
                return "ok";
            } catch (Exception e) {
                return "error";
            }
        }

        @JavascriptInterface
        public String restoreLatest() {
            try {
                if (!backupDir.exists()) return "";
                File[] files = backupDir.listFiles((dir, name) -> name.toLowerCase(Locale.US).endsWith(".json"));
                if (files == null || files.length == 0) return "";
                Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
                return readFile(files[0]);
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void pickBackup() {
            runOnUiThread(() -> {
                try {
                    if (!backupDir.exists()) backupDir.mkdirs();
                    File[] files = backupDir.listFiles((dir, name) -> name.toLowerCase(Locale.US).endsWith(".json"));
                    if (files == null || files.length == 0) {
                        Toast.makeText(MainActivity.this, "هنوز فایل پشتیبانی در پوشه برنامه وجود ندارد", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
                    String[] names = new String[files.length];
                    for (int i = 0; i < files.length; i++) names[i] = files[i].getName();
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("انتخاب پشتیبان از پوشه برنامه")
                            .setItems(names, (dialog, which) -> sendBackupToWeb(files[which]))
                            .setNegativeButton("انصراف", null)
                            .show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "دسترسی به پوشه پشتیبان ممکن نیست", Toast.LENGTH_SHORT).show();
                }
            });
        }

        private void sendBackupToWeb(File file) {
            try {
                String json = readFile(file);
                String quoted = JSONObject.quote(json);
                webView.evaluateJavascript("window.receiveNativeBackup && window.receiveNativeBackup(" + quoted + ")", null);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "خواندن فایل پشتیبان ناموفق بود", Toast.LENGTH_SHORT).show();
            }
        }

        private String readFile(File file) throws Exception {
            try (FileInputStream fis = new FileInputStream(file)) {
                byte[] data = new byte[(int) file.length()];
                int offset = 0, read;
                while (offset < data.length && (read = fis.read(data, offset, data.length - offset)) > 0) offset += read;
                return new String(data, 0, offset, StandardCharsets.UTF_8);
            }
        }
    }
}
