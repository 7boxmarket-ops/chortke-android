# CHORTKE

Android WebView wrapper for the existing `Investment_Manager_FINAL_v27.html`.

- App name: CHORTKE
- Author: 🙂HOSSEIN-7BOX
- HTML/CSS/JS kept as the source UI and logic.
- Android wrapper provides JavaScript, DOM storage, file chooser support, and Internet permission.
- GitHub Actions builds a debug APK.
