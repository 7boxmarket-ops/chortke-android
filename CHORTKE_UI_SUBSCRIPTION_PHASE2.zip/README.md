# CHORTKE — UI refinement phase 2

This is the full Android WebView project source for CHORTKE.

## Changes in this package
- Replaced the native-looking investment type and online price source pickers with branded, animated black/purple selection sheets.
- Preserved the existing select values and change events so the current investment and online price logic remains connected.
- Enlarged the crossed-out original subscription price (499,000 toman) for clearer promotional hierarchy.
- Updated subscription copy to say “۱ ماه” rather than “۳۰ روز”.
- Reduced the sign-out button size in the account settings card.

## Important status note
This package updates the UI only. Cafe Bazaar billing, server-side purchase verification, authoritative server-time trial countdown, subscription expiry enforcement, and locking/unlocking the main app are not implemented or verified by this package. The current purchase action continues to explain that Bazaar setup is required. Do not treat the app as production-ready for paid subscriptions until those backend and billing pieces are configured and tested.

## Build
The GitHub Actions workflow builds a debug APK from this project. It uses JDK 17, Android SDK 35, and Gradle 8.9.
