# CHORTKE Monetization — Implementation Status

## Product decisions recorded
- 24-hour free trial.
- Subscription price: 199,000 toman for 30 days.
- Ads should appear for both trial users and paid subscribers.
- After trial expiry or subscription expiry, core app access is restricted to a subscription purchase screen.
- User-created investment data must not be deleted on expiry.
- Renewal is manual in the initial release.

## Included in this draft
- A styled Persian subscription/paywall UI in `app/src/main/assets/index.html`.
- A placeholder ad-slot layout.
- A small JS preview API (`window.ChortkeMonetizationPreview`) to inspect trial timing and open/close the paywall during UI work.
- Safety switches intentionally disabled so this draft does not lock users out before real billing works.

## Not production-ready yet
1. Integrate the current Cafe Bazaar in-app billing SDK and configure a real subscription product in the developer console.
2. Verify purchase results using the supported Bazaar flow before granting entitlement; never trust a JS/localStorage flag.
3. Persist entitlement securely/server-side or use an appropriate validated entitlement design. Handle restore/reinstall and purchase acknowledgement/consumption requirements if applicable to the selected product type.
4. Enforce trial/expiry only after the entitlement path is complete. Client-side clock/localStorage alone can be reset or manipulated.
5. Select and integrate an actual ad network SDK; the current ad slot is only a hidden placeholder and generates no ad revenue.
6. Test expired trial, successful purchase, failed/cancelled purchase, no internet, reinstall, device clock changes, and subscription expiry.
7. Verify policy/technical requirements and current SDK version in the official Bazaar developer documentation before release.

## Important technical note
The Android project currently has no configured Bazaar billing dependency or ad-network dependency. Therefore this draft is a UI/scaffolding milestone, not a functioning paid build. Do not publish it as a paid subscription release yet.
